DOMAIN = "school_meal"
BASE_URL = "https://fatraceschool.k12ea.gov.tw/offered/meal"

MENU_TYPES = {
    0: "早點",
    1: "午餐",
    2: "午點",
}
